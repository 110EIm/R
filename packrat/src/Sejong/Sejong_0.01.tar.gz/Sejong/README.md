# Sejong

This R package contains Hangul resources for [KoNLP][konlp] package and [Sejong project][sejong] to do corpus linguistics.

Main purposes are...

* Preserve static resources for [KoNLP][konlp].
* Keep resources to do Hangul corpus linguistics(not yet fully created).
* Related functions are already implemented or scheduled to implement on [KoNLP][konlp]






[konlp]:http://cran.r-project.org/web/packages/KoNLP/index.html
[sejong]:http://www.sejong.or.kr/
